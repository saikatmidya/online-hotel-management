<!-- /about -->
 	<div class="about-wthree" id="about">
		  <div class="container">
				   <div class="ab-w3l-spa">
                            <h3 class="title-w3-agileits title-black-wthree">About Our O A S I S</h3> 
						   <p class="about-para-w3ls">"When you come to a hotel room, you want it to be grand, functional and beautiful. But you don't want things that are not useful. Sometimes you go to hotels and there are all these frames and pictures of people you don't know, and you end up hiding everything in the drawer, and then housekeeping come and put it out again."</p>
						   <img src="images/about.jpg" class="img-responsive" alt="Hair Salon">
										<div class="w3l-slider-img">
											<img src="images/a1.jpg" class="img-responsive" alt="Hair Salon">
										</div>
                                       <div class="w3ls-info-about">
										    <h4>You'll love all the amenities we offer!</h4>
											
										</div>
		          </div>
		   	<div class="clearfix"> </div>
    </div>
</div>
 	<!-- //about -->